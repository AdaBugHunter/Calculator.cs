
using System;
using System.Windows.Forms;

namespace CalculatorApp
{
    public class CalculatorForm : Form
    {
        private TextBox txtResult;
        private Button[] buttons = new Button[16];
        private string[] buttonLabels = {
            "7", "8", "9", "/",
            "4", "5", "6", "*",
            "1", "2", "3", "-",
            "0", "C", "=", "+"
        };
        private string input = "";
        private string operand1 = "";
        private string operand2 = "";
        private char operation;

        public CalculatorForm()
        {
            this.Text = "Simple Calculator";
            this.Size = new System.Drawing.Size(260, 300);

            txtResult = new TextBox() { Top = 10, Left = 10, Width = 220, ReadOnly = true };
            this.Controls.Add(txtResult);

            int top = 50, left = 10;

            for (int i = 0; i < buttons.Length; i++)
            {
                buttons[i] = new Button();
                buttons[i].Text = buttonLabels[i];
                buttons[i].Width = 50;
                buttons[i].Height = 40;
                buttons[i].Left = left;
                buttons[i].Top = top;
                buttons[i].Click += new EventHandler(this.Button_Click);
                this.Controls.Add(buttons[i]);

                left += 55;
                if ((i + 1) % 4 == 0)
                {
                    left = 10;
                    top += 45;
                }
            }
        }

        private void Button_Click(object sender, EventArgs e)
        {
            string btnText = ((Button)sender).Text;

            if (btnText == "C")
            {
                input = operand1 = operand2 = "";
                txtResult.Text = "";
            }
            else if (btnText == "=")
            {
                operand2 = input;
                double num1 = Convert.ToDouble(operand1);
                double num2 = Convert.ToDouble(operand2);
                double result = 0;

                switch (operation)
                {
                    case '+': result = num1 + num2; break;
                    case '-': result = num1 - num2; break;
                    case '*': result = num1 * num2; break;
                    case '/': result = num2 != 0 ? num1 / num2 : 0; break;
                }

                txtResult.Text = result.ToString();
                input = result.ToString();
            }
            else if ("+-*/".Contains(btnText))
            {
                operand1 = input;
                operation = btnText[0];
                input = "";
            }
            else
            {
                input += btnText;
                txtResult.Text = input;
            }
        }

        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new CalculatorForm());
        }
    }
}
